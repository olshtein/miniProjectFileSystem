﻿
namespace FMS5774_Cpp_CSharp_Adapter.RecordTypes
{
    public interface IRecord
    {
        string Key { get; set; }
    }
}
