﻿using System.Windows;

namespace FMS5774_8856_5366_WPF
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
