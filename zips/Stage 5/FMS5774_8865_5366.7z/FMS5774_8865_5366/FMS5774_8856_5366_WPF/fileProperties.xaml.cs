﻿using System.Windows.Controls;

namespace FMS5774_8856_5366_WPF
{
    /// <summary>
    /// Interaction logic for fileProperties.xaml
    /// </summary>
    public partial class fileProperties : Page
    {
        public fileProperties()
        {
            InitializeComponent();
        }
    }
}
